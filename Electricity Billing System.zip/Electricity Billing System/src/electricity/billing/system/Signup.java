package electricity.billing.system;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;

public class Signup extends JFrame implements ActionListener {
    JButton create, back;
    Choice accountType;
    JTextField meter,Name, username, password;
    Signup() {
        setBounds(340, 150, 700, 400);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(20,30,650,300);
        panel.setBorder(new TitledBorder(new LineBorder(new Color(0,153,153),2),"Create-Account", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0,153,153)));
        panel.setBackground(Color.lightGray);
        panel.setLayout(null);
        panel.setForeground(new Color(34,139,34));
        add(panel);

        JLabel heading = new JLabel("Create Account As:");
        heading.setBounds(100,50,140,20);
        heading.setFont(new Font("Tahoma",Font.BOLD, 14));
        panel.add(heading);

        accountType = new Choice();
        accountType.add("Admin");
        accountType.add("Customer");
        accountType.setBounds(240, 50,150,20);
        panel.add(accountType);

        JLabel lblmeter = new JLabel("Meter Number:");
        lblmeter.setBounds(100,90,140,20);
        lblmeter.setFont(new Font("Tahoma",Font.BOLD, 14));
        lblmeter.setVisible(false);
        panel.add(lblmeter);

        meter = new JTextField();
        meter.setBounds(240,90,150,20);
        meter.setVisible(false);
        panel.add(meter);

        meter.addFocusListener(new FocusListener(){
            @Override
            public void focusGained(FocusEvent fe) {}

            @Override
            public void focusLost(FocusEvent fe) {
                try {
                    Conn c  = new Conn();
                    ResultSet rs = c.s.executeQuery("select * from login where meter_no = '"+meter.getText()+"'");
                    while(rs.next()) {
                        Name.setText(rs.getString("name"));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        JLabel lblusername = new JLabel("Username:");
        lblusername.setBounds(100,130,140,20);
        lblusername.setFont(new Font("Tahoma",Font.BOLD, 14));
        panel.add(lblusername);

        username = new JTextField();
        username.setBounds(240,130,150,20);
        panel.add(username);

        JLabel lblname = new JLabel("Name:");
        lblname.setBounds(100,170,140,20);
        lblname.setFont(new Font("Tahoma",Font.BOLD, 14));
        panel.add(lblname);

        Name = new JTextField();
        Name.setBounds(240,170,150,20);
        panel.add(Name);

        JLabel lblpassword = new JLabel("Password:");
        lblpassword.setBounds(100,210,140,20);
        lblpassword.setFont(new Font("Tahoma",Font.BOLD, 14));
        panel.add(lblpassword);

        password = new JTextField();
        password.setBounds(240,210,150,20);
        panel.add(password);

        accountType.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent ae) {
                String user = accountType.getSelectedItem();
                if (user.equals("Customer")) {
                    lblmeter.setVisible(true);
                    meter.setVisible(true);
                    Name.setEditable(false);
                } else {
                    lblmeter.setVisible(false);
                    meter.setVisible(false);
                    Name.setEditable(true);
                }
            }
        });

        create = new JButton("Create");
        create.setBackground(Color.black);
        create.setForeground(Color.WHITE);
        create.setBounds(160,265,120,25);
        create.addActionListener(this);
        panel.add(create);

        back = new JButton("Back");
        back.setBackground(Color.black);
        back.setForeground(Color.WHITE);
        back.setBounds(300,265,120,25);
        back.addActionListener(this);
        panel.add(back);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/signup.png"));
        Image i2 = i1.getImage().getScaledInstance(246,246, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(415, 18, 246,246);
        panel.add(image);

        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == create){
            String satype = accountType.getSelectedItem();
            String susername = username.getText();
            String sname = Name.getText();
            String spassword = password.getText();
            String smeter = meter.getText();

            try{
                Conn c = new Conn();

                String query = null;
                if (accountType.equals("Admin")) {
                    query = "insert into login values('" + smeter + "','" + susername + "', '" + sname + "', '" + spassword + "', '" + satype + "')";
                }else{
                    query = query = "update login set username = '"+susername+"', password = '"+spassword+"', user = '"+satype+"' where meter_no = '"+smeter+"'";
                }

                c.s.executeUpdate(query);

                JOptionPane.showMessageDialog(null, "Account Created Successfully");

                setVisible(false);
                new Login();
            }catch (Exception e){
                e.printStackTrace();
            }
        }else if(ae.getSource() == back){
            setVisible(false);

            new Login();
        }
    }

    public static void main(String[] args) {
        new Signup();
    }
}
